function desplegar(){
    let ancla = document.getElementsByClassName("etiquetas");
    for(let i = 0; i < ancla.length; i++){
        ancla[i].classList.toggle("ocultar");
    }

    let ancla1 = document.getElementsByClassName("p1");
    for(let i = 0; i < ancla.length; i++){
        ancla1[i].classList.toggle("ocultar");
    }
    if (typeof foo !== 'undefined') {
        // Ahora sabemos que foo está definido, ahora podemos continuar.
      }
}